(function($){

	var docReady = function(){
		console.log( 'Doc ready!' );
	};

	$(document).ready(function(){
		docReady();
	});

})(jQuery);