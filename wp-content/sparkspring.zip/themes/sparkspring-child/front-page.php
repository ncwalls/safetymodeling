<?php get_header(); ?>

		<?php while( have_posts() ): the_post(); ?>
			<article <?php post_class(); ?> id="post-<?php the_ID(); ?>">
				<div class="main-logo">
					<span class="logo-text">SparkSpring</span>
					<svg version="1.1"
						 xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:a="http://ns.adobe.com/AdobeSVGViewerExtensions/3.0/"
						 x="0px" y="0px" width="101.1px" height="349.2px" viewBox="0 0 101.1 349.2" style="enable-background:new 0 0 101.1 349.2;"
						 xml:space="preserve">
						<path class="st0" d="M97.1,112.9C108,78.3,96.8,51.4,62,0.3c-1.1-1.7-6,4.8-5.3,6.5C89.5,94.8,25.1,122.4,4,189
							c-10.3,32.8-0.8,58.7,29.9,104.9c0.6,15.4,8.8,31.1,25.2,55.1c0.7,1.1,3.9-3.1,3.4-4.2c-21.2-56.7,20.4-74.6,33.9-117.5
							c6.9-21.7,0.1-38.9-21.1-70.3C83.9,143.7,91.8,129.5,97.1,112.9z M37.8,272.5C27.6,224,50.3,195.4,71.7,162.7
							C89.1,214.7,52.2,233.2,37.8,272.5z"/>
					</svg>
				</div>
				<?php
					$hero = '';
					if(get_post_thumbnail_id()){
						$hero = wp_get_attachment_image_src( get_post_thumbnail_id(), 'large')[0];
					}
				?>
				<div class="top" style="background-image: url(<?php echo $hero; ?>)">
					<div class="content">
						<h1 class="brand"><img  src="<?php the_field( 'site_logo', 'option' ); ?>" alt="<?php bloginfo( 'name' ); ?>"></h1>
<!--						<h1>Marketing Services</h1>-->
						<ul class="services">
							<li>
								 <svg version="1.1"
									 xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:a="http://ns.adobe.com/AdobeSVGViewerExtensions/3.0/"
									 x="0px" y="0px" width="101.1px" height="349.2px" viewBox="0 0 101.1 349.2" style="enable-background:new 0 0 101.1 349.2;"
									 xml:space="preserve">
									<path class="st0" d="M97.1,112.9C108,78.3,96.8,51.4,62,0.3c-1.1-1.7-6,4.8-5.3,6.5C89.5,94.8,25.1,122.4,4,189
										c-10.3,32.8-0.8,58.7,29.9,104.9c0.6,15.4,8.8,31.1,25.2,55.1c0.7,1.1,3.9-3.1,3.4-4.2c-21.2-56.7,20.4-74.6,33.9-117.5
										c6.9-21.7,0.1-38.9-21.1-70.3C83.9,143.7,91.8,129.5,97.1,112.9z M37.8,272.5C27.6,224,50.3,195.4,71.7,162.7
										C89.1,214.7,52.2,233.2,37.8,272.5z"/>
								</svg>
								<h3>Web</h3>
							</li>
							<li>
								 <svg version="1.1"
									 xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:a="http://ns.adobe.com/AdobeSVGViewerExtensions/3.0/"
									 x="0px" y="0px" width="101.1px" height="349.2px" viewBox="0 0 101.1 349.2" style="enable-background:new 0 0 101.1 349.2;"
									 xml:space="preserve">
									<path class="st0" d="M97.1,112.9C108,78.3,96.8,51.4,62,0.3c-1.1-1.7-6,4.8-5.3,6.5C89.5,94.8,25.1,122.4,4,189
										c-10.3,32.8-0.8,58.7,29.9,104.9c0.6,15.4,8.8,31.1,25.2,55.1c0.7,1.1,3.9-3.1,3.4-4.2c-21.2-56.7,20.4-74.6,33.9-117.5
										c6.9-21.7,0.1-38.9-21.1-70.3C83.9,143.7,91.8,129.5,97.1,112.9z M37.8,272.5C27.6,224,50.3,195.4,71.7,162.7
										C89.1,214.7,52.2,233.2,37.8,272.5z"/>
								</svg>
								<h3>Marketing/SEO</h3>
							</li>
							<li>
								 <svg version="1.1"
									 xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:a="http://ns.adobe.com/AdobeSVGViewerExtensions/3.0/"
									 x="0px" y="0px" width="101.1px" height="349.2px" viewBox="0 0 101.1 349.2" style="enable-background:new 0 0 101.1 349.2;"
									 xml:space="preserve">
									<path class="st0" d="M97.1,112.9C108,78.3,96.8,51.4,62,0.3c-1.1-1.7-6,4.8-5.3,6.5C89.5,94.8,25.1,122.4,4,189
										c-10.3,32.8-0.8,58.7,29.9,104.9c0.6,15.4,8.8,31.1,25.2,55.1c0.7,1.1,3.9-3.1,3.4-4.2c-21.2-56.7,20.4-74.6,33.9-117.5
										c6.9-21.7,0.1-38.9-21.1-70.3C83.9,143.7,91.8,129.5,97.1,112.9z M37.8,272.5C27.6,224,50.3,195.4,71.7,162.7
										C89.1,214.7,52.2,233.2,37.8,272.5z"/>
								</svg>
								<h3>Branding</h3>
							</li>
						</ul>
					</div>
				</div>
				<img src="<?php echo get_stylesheet_directory_uri(); ?>/images/team-nikki.png" class="nikki" alt="Nikki Chin"/>
				<div class="bottom">
					<div class="content">
						<h2>Website Coming Soon</h2>
						<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nostrum doloribus magni iste illo hic nemo eos quidem blanditiis, nihil maxime, minima rem dolorem repellat voluptatibus error non, libero praesentium? Repellat.</p>
						<ul class="social">
							<li>
								<a href="" target="_blank" class="fa fa-facebook"></a>
							</li>
							<li>
								<a href="" target="_blank" class="fa fa-twitter"></a>
							</li>
							<li>
								<a href="" target="_blank" class="fa fa-linkedin"></a>
							</li>
							<li>
								<a href="" target="_blank" class="fa fa-instagram"></a>
							</li>
						</ul>
					</div>
				</div>
				
			</article>
		<?php endwhile; ?>

<?php get_footer();