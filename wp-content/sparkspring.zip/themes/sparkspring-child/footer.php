		<footer class="site-footer">
			<div class="container">
				<?php /*<div class="left">
					<nav class="footer-inlinks">
						<ul>
							<li class="copyright">&copy;<?php echo date( 'Y' ); ?> <?php bloginfo( 'name' ); ?>.</li>
							<li><a href="<?php echo home_url( 'privacy-policy' ); ?>" title="Privacy Policy">Privacy Policy</a></li>
							<li><a href="<?php echo home_url( 'site-info' ); ?>" title="Site Info">Site Info</a></li>
							<li><a href="<?php echo home_url( 'site-map' ); ?>" title="Site Map">Site Map</a></li>
						</ul>
					</nav>
				</div>
				<div class="right">
					
				</div>*/?>
			</div>
		</footer>
		<?php wp_footer(); ?>
	</body>
</html>